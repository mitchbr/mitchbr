import json


with open("creds.json") as file:
    metaData = json.load(file)

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps(metaData["username"])
    }